<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Headers:*');
header('Content-type: application/json');
if($_GET['token'] == 'NguyenThuWan')
{
include('dom/simple_html_dom.php');
function token() {
    $html = file_get_html('https://www.codashop.com/id/arena-of-valor');
  foreach ($html->find('.main-content') as $key){
    foreach ($key->find('#checkoutId') as $a) {
      return $a->attr['value'];
    }
  }
}
$ch = curl_init();
$vars = json_encode(array(
  'voucherPricePoint.id' => '28235',
  'voucherPricePoint.price' => '10000000',
  'voucherPricePoint.variablePrice' => '0',
  'email' => 'renzichwan@gmail.com',
  'n' => date('n/d/Y-Hi'),
  'userVariablePrice' => '0',
  'order.data.profile' => 'eyJuYW1lIjoiICIsImRhdGVvZmJpcnRoIjoiIiwiaWRfbm8iOiIifQ==',
  'user.userId' => $_GET['id'],
  'voucherTypeName' => 'AOV',
  'affiliateTrackingId' => '',
  'impactClickId' => '',
  'checkoutId' => token(),
  'tmwAccessToken' => '',
  'shopLang' => 'in_ID'
  ));
curl_setopt($ch, CURLOPT_URL,"https://order.codashop.com/id/initPayment.action");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$vars);  //POST Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers[] = 'Host: order.codashop.com';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0';
$headers[] = 'Accept: text/plain, */*; q=0.01';
$headers[] = 'Accept-Language: en-US,en;q=0.5';
$headers[] = 'Accept-Encoding: UTF-8';
$headers[] = 'Content-Type: application/json; charset=UTF-8';
$headers[] = 'Referer: https://www.codashop.com/id/arena-of-valor';
$headers[] = 'Origin: https://www.codashop.com';
$headers[] = 'Connection: keep-alive';

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$res = curl_exec($ch);
$data = json_decode($res,true);
$nick =  $data['confirmationFields']['roles'][0]['role'];
$id = $data['user']['userId'];
if($nick != null)
{
$print = array(
  			'result' => array(
  				'status' => '200',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'nickname' => $nick,
  			'userid' => $id
  		);
  $hasil = json_encode($print, JSON_PRETTY_PRINT);
}else{
    $print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'error_msg' => 'Invalid Id'
  		);
  $hasil = json_encode($print, JSON_PRETTY_PRINT);
}
  print_r($hasil);
}else{
$print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'error_msg' => 'Missing Token or Parameter'
  		);
  $hasil = json_encode($print, JSON_PRETTY_PRINT);
  print_r($hasil);    
}
?>