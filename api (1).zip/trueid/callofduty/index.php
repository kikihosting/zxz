<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Headers:*');
header('Content-type: application/json');
if($_GET['token'] == 'NguyenThuWan')
{
$ch = curl_init();
$vars = json_encode(array(
    'productId' => '18',
    'itemId' => '88',
    'catalogId' => '144',
    'paymentId' => '828',
    'gameId' => $_GET['id'],
    'product_ref' => 'REG',
    'product_ref_denom' => 'REG',
    ));
curl_setopt($ch, CURLOPT_URL,"https://api.duniagames.co.id/api/transaction/v1/top-up/inquiry/store");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$vars);  //POST Fields
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers[] = 'Host: api.duniagames.co.id';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0';
$headers[] = 'Accept: application/json, text/plain, */*';
$headers[] = 'Accept-Language: id';
$headers[] = 'Ciam-Type: FR';
$headers[] = 'Content-Type: application/json';
$headers[] = 'Referer: https://duniagames.co.id/top-up/item/call-of-duty-mobile';
$headers[] = 'Origin: https://duniagames.co.id';
$headers[] = 'Connection: keep-alive';

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$res = curl_exec($ch);
$data = json_decode($res,true);
$nick =  $data['data']['userNameGame'];
$id = $data['data']['gameId'];
if($nick != null)
{
$print = array(
  			'result' => array(
  				'status' => '200',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'nickname' => $nick,
  			'userid' => $id
  		);
  $hasil = json_encode($print, JSON_PRETTY_PRINT);
}else{
    $print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'error_msg' => 'Invalid Id'
  		);
  $hasil = json_encode($print, JSON_PRETTY_PRINT);
}
  print_r($hasil);
}else{
$print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'error_msg' => 'Missing Token or Parameter'
  		);
  $hasil = json_encode($print, JSON_PRETTY_PRINT);
  print_r($hasil);    
}
?>