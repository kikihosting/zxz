<?php
header('Access-Control-Allow-Origin:*');
header('Access-Control-Allow-Headers:*');
header('Content-type: application/json');
if(isset($_GET['hp']) && isset($_GET['email']) && isset($_GET['nama']) && isset($_GET['otp']))
{
$ch = curl_init();
$vars = json_encode(array(
    'thor_customer' => array(
                  'name' => $_GET['nama'],
                  'card_number' => null,
                  'email_address' => $_GET['email'],
                  'mobile_country_code' => '+62',
                  'gender_id' => '1',
                  'mobile_number' => $_GET['hp'],
                  'mro' => '',
                  'password' => 'Berbahaya123',
                  'birth_date' => '31/01/2003'
                  ),
    'activation_request' => array(
    			  'activation_code' => $_GET['otp'],
    			  'mobile_number' => $_GET['hp'],
    			  'mobile_country_code' => '+62'
    			  )
    ));
curl_setopt($ch, CURLOPT_URL,"https://www.matahari.com/rest/V1/thorCustomers/activate");
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS,$vars); 
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$headers[] = 'Host: www.matahari.com';
$headers[] = 'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:52.0) Gecko/20100101 Firefox/52.0';
$headers[] = 'Accept: */*';
$headers[] = 'Accept-Language: en-US,en;q=0.5';
$headers[] = 'Accept-Encoding: gzip, deflate, br';
$headers[] = 'X-NewRelic-ID: Vg4GVFVXDxAGVVlVBgcGVlY=';
$headers[] = 'Content-Type: application/json';
$headers[] = 'x-requested-with: XMLHttpRequest';
$headers[] = 'Referer: https://www.matahari.com/customer/account/create/';
$headers[] = 'Connection: keep-alive';

curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

$res = curl_exec($ch);
$data = json_decode($res,true);
if($data['outcome_message'] == "Active successfully")
{
$print = array(
  			'result' => array(
  				'status' => '200',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'messege' => 'Berhasil Di Aktivasi',
  		);
$hasil = json_encode($print, JSON_PRETTY_PRINT);
print_r($hasil); 
}

if($data['message'] == "OTP yg anda masukkan salah")
{
$print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'messege' => 'Wrong OTP',
  		);
$hasil = json_encode($print, JSON_PRETTY_PRINT);
print_r($hasil);   
}
if($data['message'] == "OTP request is lock. Please try again in 30 minutes")
{
 $print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'messege' => 'Mohon tunggu 30 menit, lalu coba lagi',
  		);
$hasil = json_encode($print, JSON_PRETTY_PRINT);
print_r($hasil);   
}
}else{
$print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'error_msg' => 'Invalid or Missing Parameter',
  		);
$hasil = json_encode($print, JSON_PRETTY_PRINT);
print_r($hasil); 
}
?>