<?php
header('Access-Control-Allow-Origin:*');
header('Content-type: application/json');
if(isset($_GET['hp']))
{
$providerList = [
	"Telkomsel" => [
		"0811",
		"0812",
		"0813",
		"0821",
		"0822",
		"0823",
		"0852",
		"0853",
	],
	"By.u" => [
	    "0851"
	],
	"Indosat" => [
		"0814",
		"0815",
		"0816",
		"0855",
		"0856",
		"0857",
		"0858",
	],
	"Xl" => [
		"0817",
		"0818",
		"0819",
		"0859",
		"0877",
		"0878",
	],
	"Tri" => [
		"0895",
		"0896",
		"0897",
		"0898",
		"0899",
	],
	"Axis" => [
		"0838",
		"0831",
		"0832",
		"0833",
	]
];

$wasted = preg_replace('/[^\p{L}\p{N}\s]/u', '', $_GET['hp']);
$as = str_replace(' ','',$wasted);
$filter = substr($as,0,2);
	if($filter == 62)
	{
		$filter2 = substr($as, 2);
		$myNumber = '0'.$filter2;
	}else{
		$myNumber = $as;
	}

$result = null;
foreach ($providerList as $key => $value) {
	foreach ($value as $key2 => $value2) {
		if (preg_match("/^{$value2}.*/", $myNumber))
		{
			$result = $key;
			break;
		}
	}
}
$print = array(
  			'result' => array(
  				'status' => '200',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'provider' => $result,
  			'number' => $myNumber
  		);
$hasil = json_encode($print, JSON_PRETTY_PRINT);
print_r($hasil);
}else{
$print = array(
  			'result' => array(
  				'status' => '404',
  				'Author' => 'Nguyen Thu Wan'
  			),
  			'error_msg' => 'Invalid or Missing Phone Number'
  		);
$hasil = json_encode($print, JSON_PRETTY_PRINT);
print_r($hasil);
}